// const express = require('express');
// const fs = require('fs');
// // import { mkdir } from 'node:fs/promises';
// const path = require('path');
// const unzipper = require('unzipper');
// const vm = require('vm');
// const { exec } = require('child_process');

// // import { fileURLToPath, pathToFileURL } from 'url';
// const { pathToFileURL } = require('url');
// const { createRequire } = require('module');

import { fileURLToPath, pathToFileURL } from 'url';

import express from 'express';
import bodyParser from 'body-parser';
import path from 'path';
import AppLoader from "./loader/index.mjs"
import dbManager from "./engine/databases/index.mjs"
import fs from 'fs';

import appGuard from './engine/middleware/app-guard/index.mjs';
import createLogger from './engine/app-logger/index.mjs';

// import vm from 'vm';
// import { createRequire } from 'module';

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadsDir = path.join(__dirname, 'uploads');
const appsDir = path.join(__dirname, 'apps');

const apps = []

// Watch for new files in the `uploads` directory
const watchUploadsDir = (app, apps) => {
    fs.watch(uploadsDir, async (eventType, filename) => {
        if (eventType === 'rename' && filename.endsWith('.zip')) {
            const filePath = path.join(uploadsDir, filename);
            const appName = filename.split(".")[0];
            const appVersion = filename.split(".")[1];
            const appInfo = {
                id: appName,
                version: appVersion,                
            }
            appInfo.path = path.join(__dirname, `apps/${appInfo.id}/${appInfo.version}`)
            appInfo.urlContext = `/${appInfo.id}/${appInfo.version}`   

            if(fs.existsSync(filePath)){                
                console.log(`New zip file detected: ${filename}`);
                
                // const appLoader = AppLoader.getInstance();
                // // make app dir beforehand
                // const appDb = await dbManager.connectAppDB(appInfo)
                // const logger = createLogger(appInfo)
                // await appLoader.loadAppArchive(appInfo, app, appDb, logger, filePath)
                try{
                  await loadApp(appInfo, app, filePath);
                  apps.push(appInfo);
                }catch(error){
                  console.error(`Eroor loading app ${JSON.stringify(appInfo)}`, error);
                }
                
            }else{
                // file is removed, so remove application files (can be redeployed later on or will not
                // deploy on next restart)
                console.log(`Going to remove data for : ${filename} ...`);
                const index = apps.findIndex(item=>item.urlContext == appInfo.urlContext)
                if(index!=-1) apps.splice(index,1);

                fs.rmSync(path.join(__dirname, `apps/${appInfo.id}`), { recursive: true, force: true });
                console.log(`Going to remove data for : ${filename} ... DONE`);
                

            }            
        }
    });
};

const readDeployedAppsInfos = (appsDir)=>{
    const appInfos = [];

    // Read the apps directory to get app ID directories
    const appIds = fs.readdirSync(appsDir);
  
    appIds.forEach((appId) => {
      const appDir = path.join(appsDir, appId);
  
      // Check if appDir is a directory
      if (fs.statSync(appDir).isDirectory()) {
        // Read each app directory to get version directories
        const versions = fs.readdirSync(appDir);
  
        versions.forEach((version) => {
          const versionDir = path.join(appDir, version);
  
          // Check if versionDir is a directory
          if (fs.statSync(versionDir).isDirectory()) {            
            const indexFilePath = path.join(versionDir, 'index.mjs');
  
            // Check if index.mjs file exists in the version directory
            if (fs.existsSync(indexFilePath)) {
                const appInfo = {
                    id: appId,
                    version: version,    
                    path: versionDir,
                    urlContext: `/${appId}/${version}`            
                }
                appInfos.push(appInfo);
            //   // Read and print the content of index.mjs
            //   const content = fs.readFileSync(indexFilePath, 'utf-8');
            //   console.log(`Contents of ${indexFilePath}:\n${content}\n`);
            } else {
                console.log(`No index.mjs file found in ${versionDir}`);
            }
          }
        });
      }
    });
    console.log(`Detected ${appInfos.length} apps`)
    appInfos.forEach(item=>console.log(`${item.id}-${item.version}`))
    return appInfos;
  }

const loadInstalledApps = async (app, apps) => {
    const appInfos = readDeployedAppsInfos(appsDir);
    console.log(`Going to load installed apps ...`);
    appInfos.forEach(item=>console.log(`${item.id}.v${item.version}`))
    

    for(let i=0; i< appInfos.length; i++){
      try{
        const appInfo = appInfos[i];
        // const appLoader = AppLoader.getInstance();
        // // make app dir beforehand
        // const appDb = await dbManager.connectAppDB(appInfo)
        // const logger = createLogger(appInfo)

        // appLoader.loadApp(appInfo, app, appDb, logger);
        await loadApp(appInfo, app);
        apps.push(appInfo);
      }catch(error){
        console.error(`Error loading app ${JSON.stringify(appInfo)}`, error);
      }
        
    }
    console.log(`Going to load installed apps ... DONE.`);
}

const loadApp = async (appInfo, app, zipFilePath)=>{
  const appLoader = AppLoader.getInstance();
  // make app dir beforehand
  const appDb = await dbManager.connectAppDB(appInfo)
  const logger = createLogger(appInfo)

  appLoader.loadApp(appInfo, app, appDb, logger, zipFilePath);  
}

app.use(appGuard(apps))
app.use(bodyParser.urlencoded({ extended: true, limit: "1000mb" }));
app.use(bodyParser.json({limit: "1000mb"}));

// this is for case when deploying an app that has some major error that
// otherwise would take down whole instance
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);

  // Optionally perform clean-up or logging
  // Decide whether to exit the process or keep it running
});

// Start the server
app.listen(PORT, async () => {
    
    await loadInstalledApps(app, apps);
    watchUploadsDir(app, apps);
  // start existing apps
    console.log(`Node Microservices Api running on port: ${PORT}`);
    console.log(`New microservices zip packages can be deployed to ${uploadsDir}.`)
    console.log(`Installe ms are running from ${appsDir}`)
  
});
